export class TaskRepository{
    
}